# --- Стандартные библиотеки ---
from itertools import combinations

# --- Внутренние модули ---
from services.config import load_config, save_config

# ────────────────────────────────────────────────────────────────────
#                ПОЛУЧИТЬ ОБЩИЙ БАЛАНС ЗВЁЗД ПО ТРАНЗАКЦИЯМ
# ────────────────────────────────────────────────────────────────────
async def get_stars_balance(bot) -> int:
    """
    Возвращает суммарный баланс звёзд через API бота.
    """
    offset, limit, balance = 0, 100, 0
    while True:
        data = await bot.get_star_transactions(offset=offset, limit=limit)
        txns = data.transactions
        if not txns:
            break
        for t in txns:
            balance += t.amount if t.source else -t.amount
        offset += limit
    return balance

# ────────────────────────────────────────────────────────────────────
#                        ОБНОВИТЬ БАЛАНС В КОНФИГЕ
# ────────────────────────────────────────────────────────────────────
async def refresh_balance(bot, user_id: int) -> int:
    """
    Получает баланс через API, сохраняет в config_<uid>.json, возвращает число.
    """
    balance = await get_stars_balance(bot)
    cfg = await load_config(user_id)
    cfg["BALANCE"] = balance
    await save_config(cfg)
    return balance

# ────────────────────────────────────────────────────────────────────
#                     ИЗМЕНИТЬ БАЛАНС В КОНФИГЕ
# ────────────────────────────────────────────────────────────────────
async def change_balance(delta: int, user_id: int) -> int:
    """
    Плюсует delta к BALANCE в конфиге указанного пользователя.
    """
    cfg = await load_config(user_id)
    cfg["BALANCE"] = max(0, cfg.get("BALANCE", 0) + delta)
    await save_config(cfg)
    return cfg["BALANCE"]

# ────────────────────────────────────────────────────────────────────
#                ВОЗВРАТ ВСЕХ ЗВЁЗД, КОТОРЫЕ МОЖНО ВЕРНУТЬ
# ────────────────────────────────────────────────────────────────────
async def refund_all_star_payments(
    bot,
    username: str,
    user_id: int,
    message_func=None
):
    """
    Возвращает звёзды по депозитам указанного username без возврата.
    Оптимально подбирает комбинацию транзакций под доступный баланс.
    """
    balance = await refresh_balance(bot, user_id)
    if balance <= 0:
        return {"refunded": 0, "count": 0, "txn_ids": [], "left": 0}

    # 1. собираем ВСЕ транзакции
    offset, limit, all_txns = 0, 100, []
    while True:
        res = await bot.get_star_transactions(offset=offset, limit=limit)
        tx = res.transactions
        if not tx:
            break
        all_txns.extend(tx)
        offset += limit

    # 2. фильтруем депозиты нужного username без возврата
    deposits = [
        t for t in all_txns
        if t.source and getattr(t.source, "user", None)
        and getattr(t.source.user, "username", None) == username
    ]
    refunded_ids = {t.id for t in all_txns if t.source is None}
    unrefunded = [t for t in deposits if t.id not in refunded_ids]

    # 3. ищем лучшую комбинацию
    n = len(unrefunded)
    best, best_sum = [], 0
    if n <= 18:
        for r in range(1, n + 1):
            for combo in combinations(unrefunded, r):
                s = sum(t.amount for t in combo)
                if best_sum < s <= balance:
                    best, best_sum = combo, s
                if best_sum == balance:
                    break
            if best_sum == balance:
                break
    else:
        unrefunded.sort(key=lambda t: t.amount, reverse=True)
        curr = 0
        for t in unrefunded:
            if curr + t.amount <= balance:
                best.append(t)
                curr += t.amount
        best_sum = curr

    if not best:
        return {"refunded": 0, "count": 0, "txn_ids": [], "left": balance}

    # 4. делаем возвраты
    total_ref, refund_ids = 0, []
    for txn in best:
        tid = getattr(txn, "id", None)
        if not tid:
            continue
        try:
            await bot.refund_star_payment(
                user_id=user_id,
                telegram_payment_charge_id=tid
            )
            total_ref += txn.amount
            refund_ids.append(tid)
        except Exception:
            if message_func:
                await message_func(f"🚫 Ошибка при возврате ★{txn.amount}")

    left = balance - best_sum

    # 5. ищем «следующий» депозит, которым можно покрыть остаток
    unused = [t for t in unrefunded if t not in best]
    next_dep = None
    if left > 0:
        bigger = [t for t in unused if t.amount > left]
        if bigger:
            best_t = min(bigger, key=lambda t: t.amount)
            next_dep = {"amount": best_t.amount, "id": getattr(best_t, "id", None)}

    return {
        "refunded": total_ref,
        "count":    len(refund_ids),
        "txn_ids":  refund_ids,
        "left":     left,
        "next_deposit": next_dep,
    }