# services/menu.py
# ────────────────────────────────────────────────────────────────
# --- Сторонние библиотеки ---
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.exceptions import TelegramBadRequest
from aiogram.utils.keyboard import InlineKeyboardBuilder

# --- Внутренние библиотеки ---
from services.config import (
    load_config,
    save_config,
    get_valid_config,
    format_config_summary,
)

# ────────────────────────────────────────────────────────────────
#                 РАБОТА С ID ПОСЛЕДНЕГО МЕНЮ-СООБЩЕНИЯ
# ────────────────────────────────────────────────────────────────
async def update_last_menu_message_id(user_id: int, message_id: int):
    """Сохраняет id последнего сообщения меню в конфиг пользователя."""
    cfg = await load_config(user_id)
    cfg["LAST_MENU_MESSAGE_ID"] = message_id
    await save_config(cfg)


async def get_last_menu_message_id(user_id: int):
    """Возвращает id последнего меню из конфига пользователя."""
    cfg = await load_config(user_id)
    return cfg.get("LAST_MENU_MESSAGE_ID")

# ────────────────────────────────────────────────────────────────
#           КНОПКИ ДЕЙСТВ МЕНЮ (без изменений в логике)
# ────────────────────────────────────────────────────────────────
def config_action_keyboard(active: bool) -> InlineKeyboardMarkup:
    toggle_text = "🔴 Выключить" if active else "🟢 Включить"
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=toggle_text, callback_data="toggle_active"),
            InlineKeyboardButton(text="✏️ Изменить", callback_data="profiles_menu"),
        ],
        [
            InlineKeyboardButton(text="♻️ Сбросить", callback_data="reset_bought"),
            InlineKeyboardButton(text="❓ Помощь",   callback_data="show_help"),
        ],
        [
            InlineKeyboardButton(text="💰 Пополнить", callback_data="deposit_menu"),
            InlineKeyboardButton(text="↩️ Вывести",  callback_data="refund_menu"),
        ],
        [
            InlineKeyboardButton(text="🎏 Каталог подарков", callback_data="catalog"),
        ],
    ])

# ────────────────────────────────────────────────────────────────
#                    ОБНОВИТЬ / УДАЛИТЬ / ОТПРАВИТЬ МЕНЮ
# ────────────────────────────────────────────────────────────────
async def update_menu(bot, chat_id: int, user_id: int, message_id: int):
    """
    Обновляет меню: удаляет предыдущее (если надо) и отправляет новое.
    """
    cfg = await get_valid_config(user_id)
    await delete_menu(bot=bot, chat_id=chat_id, user_id=user_id,
                      current_message_id=message_id)
    await send_menu(
        bot=bot,
        chat_id=chat_id,
        user_id=user_id,
        config=cfg,
        text=format_config_summary(cfg, user_id),
    )


async def delete_menu(bot, chat_id: int, user_id: int, current_message_id: int = None):
    """
    Удаляет предыдущее меню-сообщение, если оно существует и отличается от текущего.
    """
    last_id = await get_last_menu_message_id(user_id)
    if last_id and last_id != current_message_id:
        try:
            await bot.delete_message(chat_id=chat_id, message_id=last_id)
        except TelegramBadRequest as e:
            err = str(e)
            if "message can't be deleted for everyone" in err:
                await bot.send_message(
                    chat_id,
                    "⚠️ Предыдущее меню устарело и не может быть удалено "
                    "(прошло более 48 ч). Используйте актуальное меню.",
                )
            elif "message to delete not found" in err:
                pass
            else:
                raise


async def send_menu(bot, chat_id: int, user_id: int, config: dict, text: str) -> int:
    """
    Отправляет новое меню и сохраняет его message_id.
    """
    sent = await bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=config_action_keyboard(config.get("ACTIVE")),
    )
    await update_last_menu_message_id(user_id, sent.message_id)
    return sent.message_id

# ────────────────────────────────────────────────────────────────
#                     КНОПКА ОПЛАТЫ ДЛЯ ИНВОЙСА
# ────────────────────────────────────────────────────────────────
def payment_keyboard(amount: int):
    builder = InlineKeyboardBuilder()
    builder.button(text=f"Пополнить ★{amount:,}", pay=True)
    return builder.as_markup()