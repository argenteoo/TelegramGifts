# -*- coding: utf-8 -*-
"""
services/config.py

• Полностью совместим с исходной версией (≈300 строк).  
• Каждый пользователь хранит настройки в  configs/config_<uid>.json
"""

# ─────────────────────────────────────────────────────────────────────
#                      СТАНДАРТНЫЕ БИБЛИОТЕКИ
# ─────────────────────────────────────────────────────────────────────
import json
import os
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List

# ─────────────────────────────────────────────────────────────────────
#                       СТОРОННЯЯ БИБЛИОТЕКА
# ─────────────────────────────────────────────────────────────────────
import aiofiles   # асинхронная работа с файлами

# ─────────────────────────────────────────────────────────────────────
#                               ЛОГГЕР
# ─────────────────────────────────────────────────────────────────────
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────
#                              КОНСТАНТЫ
# ─────────────────────────────────────────────────────────────────────
CURRENCY           = "XTR"
VERSION            = "1.2.0"
DEV_MODE           = False
MAX_PROFILES       = 3
PURCHASE_COOLDOWN  = 0.3   # секунды

# Папка, где лежат ВСЕ конфиги
CONFIG_DIR = Path("configs")
CONFIG_DIR.mkdir(parents=True, exist_ok=True)

def get_config_path(user_id: int) -> str:
    """configs/config_<uid>.json"""
    return str(CONFIG_DIR / f"config_{user_id}.json")

# ─────────────────────────────────────────────────────────────────────
#                       ШАБЛОНЫ ПРОФИЛЯ / КОНФИГА
# ─────────────────────────────────────────────────────────────────────
def DEFAULT_PROFILE(user_id: int) -> dict:
    return {
        "MIN_PRICE":      5000,
        "MAX_PRICE":     10000,
        "MIN_SUPPLY":     1000,
        "MAX_SUPPLY":    10000,
        "LIMIT":       1000000,
        "COUNT":              5,
        "TARGET_USER_ID": user_id,
        "TARGET_CHAT_ID": None,
        "BOUGHT":             0,
        "SPENT":              0,
        "DONE":           False,
    }

def DEFAULT_CONFIG(user_id: int) -> dict:
    return {
        "OWNER_ID": user_id,
        "BALANCE":  0,
        "ACTIVE":   False,
        "LAST_MENU_MESSAGE_ID": None,
        "PROFILES": [DEFAULT_PROFILE(user_id)],
    }

# ─────────────────────────────────────────────────────────────────────
#                     ОПИСАНИЕ ТИПОВ ДЛЯ ВАЛИДАЦИИ
# ─────────────────────────────────────────────────────────────────────
PROFILE_TYPES = {
    "MIN_PRICE":      (int, False),
    "MAX_PRICE":      (int, False),
    "MIN_SUPPLY":     (int, False),
    "MAX_SUPPLY":     (int, False),
    "LIMIT":          (int, False),
    "COUNT":          (int, False),
    "TARGET_USER_ID": (int, True),
    "TARGET_CHAT_ID": (str, True),
    "BOUGHT":         (int, False),
    "SPENT":          (int, False),
    "DONE":           (bool, False),
}

CONFIG_TYPES = {
    "OWNER_ID":             (int,  False),
    "BALANCE":              (int,  False),
    "ACTIVE":               (bool, False),
    "LAST_MENU_MESSAGE_ID": (int,  True),
    "PROFILES":             (list, False),
}

def _is(value, typ, allow_none=False):
    return (value is None and allow_none) or isinstance(value, typ)

# ─────────────────────────────────────────────────────────────────────
#                      ФУНКЦИИ РАБОТЫ С ФАЙЛОМ
# ─────────────────────────────────────────────────────────────────────
async def ensure_config(user_id: int) -> None:
    path = get_config_path(user_id)
    if not os.path.exists(path):
        async with aiofiles.open(path, "w", encoding="utf-8") as f:
            await f.write(json.dumps(DEFAULT_CONFIG(user_id), indent=2))
        logger.info("Создан конфиг %s", path)

async def load_config(user_id: int) -> dict:
    path = get_config_path(user_id)
    if not os.path.exists(path):
        raise FileNotFoundError(f"{path} не найден. Сначала ensure_config().")
    async with aiofiles.open(path, "r", encoding="utf-8") as f:
        return json.loads(await f.read())

async def save_config(config: dict) -> None:
    uid = config.get("OWNER_ID")
    if uid is None:
        raise ValueError("save_config: нет OWNER_ID")
    path = get_config_path(uid)
    async with aiofiles.open(path, "w", encoding="utf-8") as f:
        await f.write(json.dumps(config, indent=2))
    logger.info("Конфиг %s сохранён", path)

# ─────────────────────────────────────────────────────────────────────
#                          ВАЛИДАЦИЯ
# ─────────────────────────────────────────────────────────────────────
async def validate_profile(profile: dict, user_id: int) -> dict:
    valid = {}
    default = DEFAULT_PROFILE(user_id)
    for k, (tp, allow_none) in PROFILE_TYPES.items():
        valid[k] = profile[k] if k in profile and _is(profile[k], tp, allow_none) else default[k]
    return valid

async def validate_config(cfg: dict, user_id: int) -> dict:
    valid = {}
    default = DEFAULT_CONFIG(user_id)
    for k, (tp, allow_none) in CONFIG_TYPES.items():
        if k == "PROFILES":
            v_profiles = [await validate_profile(p, user_id) for p in cfg.get("PROFILES", [])]
            valid[k] = v_profiles or [DEFAULT_PROFILE(user_id)]
        else:
            valid[k] = cfg[k] if k in cfg and _is(cfg[k], tp, allow_none) else default[k]
    return valid

async def get_valid_config(user_id: int) -> dict:
    await ensure_config(user_id)
    cfg  = await load_config(user_id)
    new  = await validate_config(cfg, user_id)
    new["OWNER_ID"] = user_id
    if new != cfg:
        await save_config(new)
    return new

# ─────────────────────────────────────────────────────────────────────
#                       МИГРАЦИЯ LEGACY config.json
# ─────────────────────────────────────────────────────────────────────
async def migrate_config_if_needed(user_id: int) -> None:
    legacy = Path("config.json")
    if not legacy.exists():
        return
    async with aiofiles.open(legacy, "r", encoding="utf-8") as f:
        try:
            data = json.loads(await f.read())
        except Exception:
            logger.error("Повреждённый legacy config.json удалён.")
            legacy.unlink()
            return
    data["OWNER_ID"] = user_id
    async with aiofiles.open(get_config_path(user_id), "w", encoding="utf-8") as f:
        await f.write(json.dumps(data, indent=2))
    legacy.unlink()
    logger.info("Мигрировал старый config.json → configs/config_%s.json", user_id)

# ─────────────────────────────────────────────────────────────────────
#               РАБОТА С ПРОФИЛЯМИ (функции без изменений)
# ─────────────────────────────────────────────────────────────────────
async def get_profile(config: dict, index: int=0) -> dict:
    profiles = config.get("PROFILES", [])
    if not profiles:
        raise ValueError("Нет профилей")
    return profiles[index]

async def add_profile(config: dict, profile: dict, save: bool=True) -> dict:
    config.setdefault("PROFILES", []).append(profile)
    if save:
        await save_config(config)
    return config

async def update_profile(config: dict, index: int, new_profile: dict, save: bool=True) -> dict:
    if index >= len(config.get("PROFILES", [])):
        raise IndexError("Профиль не найден")
    config["PROFILES"][index] = new_profile
    if save:
        await save_config(config)
    return config

async def remove_profile(config: dict, index: int, user_id: int, save: bool=True) -> dict:
    if index >= len(config.get("PROFILES", [])):
        raise IndexError("Профиль не найден")
    config["PROFILES"].pop(index)
    if not config["PROFILES"]:
        config["PROFILES"].append(DEFAULT_PROFILE(user_id))
    if save:
        await save_config(config)
    return config

# ─────────────────────────────────────────────────────────────────────
#                ФОРМАТИРОВАНИЕ ДЛЯ МЕНЮ / ОТЧЁТА
# ─────────────────────────────────────────────────────────────────────
def get_target_display(profile: dict, user_id: int) -> str:
    tchat = profile.get("TARGET_CHAT_ID")
    tuid  = profile.get("TARGET_USER_ID")
    if tchat:
        return f"{tchat} (Канал)"
    if tuid == user_id:
        return f"<code>{tuid}</code> (Вы)"
    return f"<code>{tuid}</code>"

def get_target_display_local(tuid: int,
                             tchat: Optional[str],
                             user_id: int) -> str:
    """Версия для handlers_catalog.py"""
    if tchat:
        return f"{tchat} (Канал)"
    if str(tuid) == str(user_id):
        return f"<code>{tuid}</code> (Вы)"
    return f"<code>{tuid}</code>"

def format_config_summary(cfg: dict, uid: int) -> str:
    status = "🟢 Активен" if cfg.get("ACTIVE") else "🔴 Неактивен"
    lines: List[str] = [f"🚦 <b>Статус:</b> {status}"]
    for i, p in enumerate(cfg.get("PROFILES", []), 1):
        state = " ✅ <b>(завершён)</b>" if p.get("DONE") else \
                " ⚠️ <b>(частично)</b>" if p.get("SPENT") else ""
        tgt   = get_target_display(p, uid)
        lines.append(
            "\n"
            f"┌🔘 <b>Профиль {i}</b>{state}\n"
            f"├💰 <b>Цена:</b> {p['MIN_PRICE']:,}–{p['MAX_PRICE']:,} ★\n"
            f"├📦 <b>Саплай:</b> {p['MIN_SUPPLY']:,}–{p['MAX_SUPPLY']:,}\n"
            f"├🎁 <b>Куплено:</b> {p['BOUGHT']:,}/{p['COUNT']:,}\n"
            f"├⭐️ <b>Лимит:</b> {p['SPENT']:,}/{p['LIMIT']:,} ★\n"
            f"└👤 <b>Получатель:</b> {tgt}"
        )
    lines.append(f"\n💰 <b>Баланс:</b> {cfg.get('BALANCE',0):,} ★")
    return "\n".join(lines)

# ─────────────────────────────────────────────────────────────────────
#                          DEBUG CLI
# ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    for f in CONFIG_DIR.glob("config_*.json"):
        print("→", f)