# ─────────────────────────────────────────────────────────────────────────────
#                               СТАНДАРТНЫЕ БИБЛИОТЕКИ
# ─────────────────────────────────────────────────────────────────────────────
import asyncio
import logging
import sys
from pathlib import Path

# добавляем корень проекта в sys.path, чтобы импорты находились отовсюду
sys.path.append(str(Path(__file__).resolve().parent))

# ─────────────────────────────────────────────────────────────────────────────
#                               СТОРОННИЕ БИБЛИОТЕКИ
# ─────────────────────────────────────────────────────────────────────────────
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

# ─────────────────────────────────────────────────────────────────────────────
#                                ВНУТРЕННИЕ МОДУЛИ
# ─────────────────────────────────────────────────────────────────────────────
from services.config import (
    ensure_config,
    save_config,
    get_valid_config,
    get_target_display,
    migrate_config_if_needed,
    DEFAULT_CONFIG,
    VERSION,
    PURCHASE_COOLDOWN,
)

from services.menu    import update_menu
from services.balance import refresh_balance
from services.gifts   import get_filtered_gifts
from services.buy     import buy_gift

from handlers.handlers_wizard  import register_wizard_handlers
from handlers.handlers_catalog import register_catalog_handlers
from handlers.handlers_main    import register_main_handlers

from utils.logging import setup_logging
from middlewares.access_control import AccessControlMiddleware
from middlewares.rate_limit     import RateLimitMiddleware

# ─────────────────────────────────────────────────────────────────────────────
#                                КОНФИГ БОТА
# ─────────────────────────────────────────────────────────────────────────────
TOKEN = "7647873890:AAGo49IovB8wLJdPkPwU70dPHkrDu7Pc_zM"

# все пользователи, которым разрешён доступ (обязательно set)
ALLOWED_USER_IDS = {
    6607507834,
    6125713641,
    7685491820,
    1834193798,
}

# ─────────────────────────────────────────────────────────────────────────────
#                                ИНИЦИАЛИЗАЦИЯ
# ─────────────────────────────────────────────────────────────────────────────
setup_logging()
logger = logging.getLogger(__name__)

bot = Bot(TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp  = Dispatcher(storage=MemoryStorage())

# ─────────────────────────────────────────────────────────────────────────────
#                                MIDDLEWARE
# ─────────────────────────────────────────────────────────────────────────────
dp.message.middleware(
    RateLimitMiddleware(
        commands_limits={"/start": 3, "/withdraw_all": 3},
        allowed_user_ids=ALLOWED_USER_IDS,
    )
)
dp.message.middleware(AccessControlMiddleware(ALLOWED_USER_IDS))
dp.callback_query.middleware(AccessControlMiddleware(ALLOWED_USER_IDS))

# ─────────────────────────────────────────────────────────────────────────────
#                                HANDLERS
# ─────────────────────────────────────────────────────────────────────────────
register_wizard_handlers(dp)
register_catalog_handlers(dp)
register_main_handlers(dp=dp, bot=bot, version=VERSION)

# ─────────────────────────────────────────────────────────────────────────────
#                                ВОРКЕР ПОКУПКИ
# ─────────────────────────────────────────────────────────────────────────────
async def gift_purchase_worker(uid: int) -> None:
    """
    Отдельная корутина на каждого разрешённого пользователя: работает
    исключительно с его файлом конфигурации configs/<uid>.json.
    """
    await refresh_balance(bot, uid)

    # бесконечный цикл
    while True:
        try:
            config = await get_valid_config(uid)

            # если пользователь выключил покупки – просто ждём
            if not config["ACTIVE"]:
                await asyncio.sleep(1)
                continue

            report_lines: list[str] = []
            progress_made = False
            any_success   = True

            # ────────────────────────────────────────────────────────
            #                    ЦИКЛ ПО ПРОФИЛЯМ
            # ────────────────────────────────────────────────────────
            for idx, profile in enumerate(config["PROFILES"]):
                if profile.get("DONE"):
                    continue

                MIN_PRICE, MAX_PRICE = profile["MIN_PRICE"], profile["MAX_PRICE"]
                MIN_SUPPLY, MAX_SUPPLY = profile["MIN_SUPPLY"], profile["MAX_SUPPLY"]
                COUNT, LIMIT = profile["COUNT"], profile.get("LIMIT", 0)
                TARGET_USER_ID, TARGET_CHAT_ID = (
                    profile["TARGET_USER_ID"],
                    profile["TARGET_CHAT_ID"],
                )

                gifts = await get_filtered_gifts(
                    bot, MIN_PRICE, MAX_PRICE, MIN_SUPPLY, MAX_SUPPLY
                )
                if not gifts:
                    continue

                purchases: list[dict] = []
                before_bought, before_spent = profile["BOUGHT"], profile["SPENT"]

                # ────────────────────────────────────────────────
                #             ЦИКЛ ПО ПОДХОДЯЩИМ ПОДАРКАМ
                # ────────────────────────────────────────────────
                for gift in gifts:
                    gid, price, file_id = (
                        gift["id"],
                        gift["price"],
                        gift["sticker_file_id"],
                    )

                    while (
                        profile["BOUGHT"] < COUNT
                        and profile["SPENT"] + price <= LIMIT
                    ):
                        ok = await buy_gift(
                            bot=bot,
                            env_user_id=uid,          # ключ: передаём свой uid
                            gift_id=gid,
                            user_id=TARGET_USER_ID,
                            chat_id=TARGET_CHAT_ID,
                            gift_price=price,
                            file_id=file_id,
                        )
                        if not ok:
                            any_success = False
                            break

                        # обновляем конфиг после покупки
                        cfg = await get_valid_config(uid)
                        profile = cfg["PROFILES"][idx]
                        profile["BOUGHT"] += 1
                        profile["SPENT"] += price
                        purchases.append({"id": gid, "price": price})
                        await save_config(cfg)

                        await asyncio.sleep(PURCHASE_COOLDOWN)

                        if profile["SPENT"] >= LIMIT:
                            break

                    if profile["BOUGHT"] >= COUNT or profile["SPENT"] >= LIMIT:
                        break  # к следующему профилю

                # ────────────────────────────────────────────────
                #            Анализ результата по профилю
                # ────────────────────────────────────────────────
                after_bought, after_spent = profile["BOUGHT"], profile["SPENT"]
                local_progress = (
                    after_bought > before_bought or after_spent > before_spent
                )

                # профиль выполнен
                if (
                    (profile["BOUGHT"] >= COUNT or profile["SPENT"] >= LIMIT)
                    and not profile["DONE"]
                ):
                    cfg = await get_valid_config(uid)
                    profile = cfg["PROFILES"][idx]
                    profile["DONE"] = True
                    await save_config(cfg)

                    target_disp = get_target_display(profile, uid)
                    summary = [
                        f"\n┌✅ <b>Профиль {idx+1}</b>",
                        f"├👤 <b>Получатель:</b> {target_disp}",
                        f"├💸 <b>Потрачено:</b> {profile['SPENT']:,} / {LIMIT:,} ★",
                        f"└🎁 <b>Куплено </b>{profile['BOUGHT']} из {COUNT}:",
                    ]
                    gift_sum: dict[int, dict] = {}
                    for p in purchases:
                        gift_sum.setdefault(p["id"], {"price": p["price"], "count": 0})[
                            "count"
                        ] += 1
                    for i, (g, d) in enumerate(gift_sum.items()):
                        prefix = "   └" if i == len(gift_sum) - 1 else "   ├"
                        summary.append(f"{prefix} {d['price']:,} ★ × {d['count']}")
                    report_lines += summary
                    progress_made = True
                    await refresh_balance(bot, uid)
                    continue

                # частичный прогресс
                if (
                    local_progress
                    and not profile["DONE"]
                    and (profile["BOUGHT"] < COUNT or profile["SPENT"] < LIMIT)
                ):
                    target_disp = get_target_display(profile, uid)
                    summary = [
                        f"\n┌⚠️ <b>Профиль {idx+1}</b> (частично)",
                        f"├👤 <b>Получатель:</b> {target_disp}",
                        f"├💸 <b>Потрачено:</b> {profile['SPENT']:,} / {LIMIT:,} ★",
                        f"└🎁 <b>Куплено </b>{profile['BOUGHT']} из {COUNT}:",
                    ]
                    gift_sum: dict[int, dict] = {}
                    for p in purchases:
                        gift_sum.setdefault(p["id"], {"price": p["price"], "count": 0})[
                            "count"
                        ] += 1
                    for i, (g, d) in enumerate(gift_sum.items()):
                        prefix = "   └" if i == len(gift_sum) - 1 else "   ├"
                        summary.append(f"{prefix} {d['price']:,} ★ × {d['count']}")
                    report_lines += summary
                    progress_made = True
                    await refresh_balance(bot, uid)
                    continue

            # ────────────────────────────────────────────────────
            #               Итог после всех профилей
            # ────────────────────────────────────────────────────
            if not any_success and not progress_made:
                config["ACTIVE"] = False
                await save_config(config)
                msg = await bot.send_message(
                    chat_id=uid,
                    text=(
                        "⚠️ Найдены подходящие подарки, но <b>не удалось</b> купить.\n"
                        "💰 Пополните баланс!\n"
                        "🚦 Статус изменён на 🔴"
                    ),
                )
                await update_menu(bot=bot, chat_id=uid, user_id=uid, message_id=msg.message_id)

            if progress_made:
                config["ACTIVE"] = not all(p.get("DONE") for p in config["PROFILES"])
                await save_config(config)
                report = (
                    "\n".join(report_lines)
                    if report_lines
                    else "⚠️ Покупок не совершено."
                )
                msg = await bot.send_message(
                    chat_id=uid,
                    text=f"🍀 <b>Отчёт по профилям:</b>\n{report}",
                )
                await update_menu(bot=bot, chat_id=uid, user_id=uid, message_id=msg.message_id)

            if all(p.get("DONE") for p in config["PROFILES"]) and config["ACTIVE"]:
                config["ACTIVE"] = False
                await save_config(config)
                msg = await bot.send_message(
                    chat_id=uid,
                    text="✅ Все профили <b>завершены</b>!\n⚠️ Нажмите ♻️ Сбросить или ✏️ Изменить!",
                )
                await update_menu(bot=bot, chat_id=uid, user_id=uid, message_id=msg.message_id)

        except Exception as e:
            logger.error("gift_purchase_worker(uid=%s): %s", uid, e)

        await asyncio.sleep(0.5)

# ─────────────────────────────────────────────────────────────────────────────
#                                   MAIN
# ─────────────────────────────────────────────────────────────────────────────
async def main() -> None:
    logger.info("Бот запущен!")

    # создаём/мигрируем конфиги и запускаем воркеры для каждого разрешённого ID
    for uid in ALLOWED_USER_IDS:
        await migrate_config_if_needed(uid)
        await ensure_config(uid)
        asyncio.create_task(gift_purchase_worker(uid))

    await dp.start_polling(bot)

# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    asyncio.run(main())
# ─────────────────────────────────────────────────────────────────────────────