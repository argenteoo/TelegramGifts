from typing import Callable, Awaitable, Any
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, InlineKeyboardMarkup, InlineKeyboardButton

class AccessControlMiddleware(BaseMiddleware):
    """Пропускает только user.id из allowed_user_ids, остальным выводит платный оффер."""

    def __init__(self, allowed_user_ids: set[int]):
        self.allowed_user_ids = allowed_user_ids

    async def __call__(
        self,
        handler: Callable[[Any, dict], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = getattr(event, "from_user", None)

        # DEBUG ‒ можно убрать
        print("[AC] in:", getattr(user, "id", None), "allowed:", self.allowed_user_ids)

        if user is None or user.id not in self.allowed_user_ids:
            kb = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🖥️ Написать владельцу",
                            url="https://t.me/lurqo",
                        )
                    ]
                ]
            )
            await event.answer(
                "⛔ <b>В мир эксклюзивных подарков доступ только по подписке!</b>\n\n"
                "🎁 Хочешь мгновенно скупать редкие подарки и быть на шаг впереди всех?\n"
                "🚀 Наш приватный автоскуп — твой билет в элиту коллекционеров.\n\n"
                "💼 Пиши владельцу, чтобы узнать детали и вступить в закрытый клуб, "
                "где каждый подарок — это шаг к легендарной коллекции.",
                reply_markup=kb,
            )
            return

        # пропускаем «своих» дальше
        return await handler(event, data)      