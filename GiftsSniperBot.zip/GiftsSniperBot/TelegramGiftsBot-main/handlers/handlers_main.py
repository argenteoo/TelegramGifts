# handlers/handlers_main.py
# ────────────────────────────────────────────────────────────────
from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    Message,
)
from aiogram.exceptions import TelegramBadRequest
from aiogram.fsm.context import FSMContext

from services.config import (
    get_valid_config,
    save_config,
    format_config_summary,
    get_target_display,
)
from services.menu import update_menu, config_action_keyboard
from services.balance import refresh_balance
from services.buy import buy_gift

router = Router(name="main")


def register_main_handlers(dp, bot, version: str) -> None:
    dp.include_router(router)

    # ───── /start ────────────────────────────────────────────────
    @router.message(CommandStart())
    async def cmd_start(message: Message, state: FSMContext) -> None:
        await state.clear()
        await refresh_balance(bot, message.from_user.id)          # ← +user_id
        await update_menu(
            bot=bot,
            chat_id=message.chat.id,
            user_id=message.from_user.id,
            message_id=None,  # посылаем новое меню-сообщение
        )

    # ───── кнопка «Вернуться в меню» ─────────────────────────────
    @router.callback_query(F.data == "main_menu")
    async def main_menu(call: CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        await call.answer()
        await refresh_balance(call.bot, call.from_user.id)        # ← +user_id
        await update_menu(
            bot=call.bot,
            chat_id=call.message.chat.id,
            user_id=call.from_user.id,
            message_id=call.message.message_id,
        )

    # ───── справка ───────────────────────────────────────────────
    @router.callback_query(F.data == "show_help")
    async def show_help(call: CallbackQuery) -> None:
        config = await get_valid_config(call.from_user.id)
        profile = config["PROFILES"][0]
        target_display = get_target_display(profile, call.from_user.id)
        bot_username = (await call.bot.get_me()).username

        help_text = (
            "<b>📖 Справка</b>\n\n"
            "🟢/🔴 — запуск или остановка покупок\n"
            "✏️ — настройка профилей\n"
            "♻️ — сброс счётчиков\n"
            "💰 — пополнение\n"
            "↩️ — вывод\n"
            "🎏 — каталог подарков\n\n"
            "❗️ Получатель должен зайти в бот "
            f"<code>@{bot_username}</code> и нажать /start\n"
            f"❗️ Тест: купите 🧸 за ★15, получатель {target_display}\n\n"
            "<b>🐸 Автор: @lurqo</b>"
        )

        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(
                    text="Тест? Купить 🧸 за ★15",
                    callback_data="buy_test_gift")],
                [InlineKeyboardButton(
                    text="☰ Вернуться в меню",
                    callback_data="main_menu")],
            ]
        )
        await call.answer()
        await call.message.answer(help_text, reply_markup=kb)

    # ───── тестовый подарок ─────────────────────────────────────
    @router.callback_query(F.data == "buy_test_gift")
    async def buy_test(call: CallbackQuery) -> None:
        gift_id = "5170233102089322756"
        config = await get_valid_config(call.from_user.id)
        profile = config["PROFILES"][0]
        TARGET_USER_ID = profile["TARGET_USER_ID"]
        TARGET_CHAT_ID = profile["TARGET_CHAT_ID"]
        target_display = get_target_display(profile, call.from_user.id)

        ok = await buy_gift(
            bot=call.bot,
            env_user_id=call.from_user.id,
            gift_id=gift_id,
            user_id=TARGET_USER_ID,
            chat_id=TARGET_CHAT_ID,
            gift_price=15,
            file_id=None,
        )
        await call.answer()
        if not ok:
            await call.message.answer(
                "⚠️ Не удалось купить 🧸 за ★15. Пополните баланс."
            )
        else:
            await call.message.answer(
                f"✅ Подарок 🧸 за ★15 куплен. Получатель: {target_display}."
            )
        await update_menu(
            bot=call.bot,
            chat_id=call.message.chat.id,
            user_id=call.from_user.id,
            message_id=call.message.message_id,
        )

    # ───── сброс счётчиков ──────────────────────────────────────
    @router.callback_query(F.data == "reset_bought")
    async def reset_bought(call: CallbackQuery) -> None:
        config = await get_valid_config(call.from_user.id)
        for p in config["PROFILES"]:
            p.update(BOUGHT=0, SPENT=0, DONE=False)
        config["ACTIVE"] = False
        await save_config(config)
        txt = format_config_summary(config, call.from_user.id)
        try:
            await call.message.edit_text(
                txt, reply_markup=config_action_keyboard(config["ACTIVE"])
            )
        except TelegramBadRequest as e:
            if "message is not modified" not in str(e):
                raise
        await call.answer("Счётчики обнулены.")

    # ───── переключение ACTIVE ─────────────────────────────────
    @router.callback_query(F.data == "toggle_active")
    async def toggle_active(call: CallbackQuery) -> None:
        config = await get_valid_config(call.from_user.id)
        config["ACTIVE"] = not config.get("ACTIVE", False)
        await save_config(config)
        txt = format_config_summary(config, call.from_user.id)
        await call.message.edit_text(
            txt, reply_markup=config_action_keyboard(config["ACTIVE"])
        )
        await call.answer("Статус обновлён.")

    # ───── платежи ──────────────────────────────────────────────
    @router.pre_checkout_query()
    async def pre_checkout(pre_checkout_query):
        await pre_checkout_query.answer(ok=True)

    @router.message(F.successful_payment)
    async def successful_payment(message: Message) -> None:
        await message.answer(
            "✅ Баланс пополнен.", message_effect_id="5104841245755180586"
        )
        await refresh_balance(message.bot, message.from_user.id)   # ← +user_id
        await update_menu(
            bot=message.bot,
            chat_id=message.chat.id,
            user_id=message.from_user.id,
            message_id=message.message_id,
        )